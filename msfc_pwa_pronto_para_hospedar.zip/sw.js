/* ════════════════════════════════════════════════════════════════════
   MSFC — Service Worker
   ────────────────────────────────────────────────────────────────────
   Faz o app abrir OFFLINE depois de instalado: na primeira visita (com
   internet ou na rede local), guarda uma cópia de cada arquivo do app
   no cache do navegador. Nas próximas aberturas, serve essa cópia na
   hora — e ainda tenta buscar uma versão mais nova em segundo plano,
   pra não ficar preso pra sempre numa versão antiga.

   Só entra em ação quando o app é aberto via http/https ou localhost
   (é a própria página, em MSFC_v4.8_dashboards.html, que decide isso —
   em file:// este arquivo nem chega a ser registrado).

   Pra publicar uma atualização: troque o número da CACHE_NAME abaixo.
   Isso faz o navegador esquecer o cache antigo e gravar tudo de novo.
   ════════════════════════════════════════════════════════════════════ */
const CACHE_NAME = 'msfc-si-v29';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png'
];

/* ══════════════════════════════════════════════════════════════════
   CORREÇÃO CRÍTICA (build 30ago) — "a página cai sozinha, no meio de eu
   digitando, tipo uma queda de energia"
   ──────────────────────────────────────────────────────────────────
   Era este skipWaiting() aqui embaixo, chamado sem condição nenhuma
   assim que uma versão nova terminava de instalar. O index.html tem uma
   tela "Nova versão disponível" com botão "Atualizar agora" / "Depois"
   — feita EXATAMENTE pra isso nunca acontecer sem escolha do operador
   (ver msfcAvisoAtualizacao). Só que esse aviso não tinha efeito
   nenhum na prática: o skipWaiting() automático aqui já tinha
   promovido a versão nova a "ativa" e tomado o controle da página
   ANTES de o operador conseguir ler ou clicar em qualquer botão —
   o "Atualizar agora" postava uma mensagem que este arquivo nem
   escutava (não existia listener de 'message' nenhum aqui).
   E como o "fetch" abaixo já busca uma cópia mais nova em segundo
   plano a cada requisição (pra funcionar offline), uma versão nova do
   app publicada durante o turno era detectada a qualquer momento —
   inclusive no meio de um cadastro sendo digitado — disparando reload
   da página sem aviso nenhum. Dado ainda não salvo (formulário aberto,
   sem ter clicado em "Registrar") se perdia nesse instante: exatamente
   os "registros que estava preenchendo" que a Gleiciane relatou ter
   que refazer.

   AGORA: skipWaiting() só roda quando ESTE arquivo recebe a mensagem
   'MSFC_ATUALIZAR_AGORA' — que só é enviada quando o operador realmente
   clica em "Atualizar agora" na tela de aviso. Sem esse clique, a
   versão nova fica esperando, quieta, e a aba aberta continua
   exatamente na versão que já estava rodando (sem clients.claim(),
   sem controllerchange, sem reload). Só quando todas as abas antigas
   forem fechadas é que o navegador ativa a versão nova sozinho, do
   jeito padrão e seguro — sem ninguém no meio de um registro pra
   interromper. */
self.addEventListener('install', function (e) {
  e.waitUntil(
    caches.open(CACHE_NAME)
      .then(function (cache) { return cache.addAll(APP_SHELL); })
      .catch(function () { /* algum arquivo do pacote pode faltar — segue sem travar */ })
  );
});

self.addEventListener('message', function (e) {
  if (e.data && e.data.type === 'MSFC_ATUALIZAR_AGORA') {
    self.skipWaiting();
  }
});

self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys()
      .then(function (nomes) {
        return Promise.all(nomes.filter(function (n) { return n !== CACHE_NAME; }).map(function (n) { return caches.delete(n); }));
      })
      .then(function () { return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function (e) {
  if (e.request.method !== 'GET') return;

  e.respondWith(
    caches.match(e.request).then(function (cached) {
      // Busca uma versão mais nova em segundo plano (não trava a resposta,
      // só atualiza o cache pra próxima vez).
      var buscaRede = fetch(e.request).then(function (resp) {
        if (resp && resp.status === 200) {
          var copia = resp.clone();
          caches.open(CACHE_NAME).then(function (cache) { cache.put(e.request, copia); });
        }
        return resp;
      }).catch(function () { return cached; });

      // Tem no cache? Responde na hora (rápido, funciona offline).
      // Sem cache ainda? Espera a rede.
      return cached || buscaRede;
    })
  );
});
